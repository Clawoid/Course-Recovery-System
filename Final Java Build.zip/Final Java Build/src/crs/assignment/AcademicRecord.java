package crs.assignment;

public class AcademicRecord {

    private String studentName;
    private String studentId;
    private String program;
    private String courseCode;
    private String courseTitle;
    private double creditHours;
    private String grade;
    private double gradePoint;

    public AcademicRecord(String studentName, String studentId, String program,
                          String courseCode, String courseTitle,
                          double creditHours, String grade, double gradePoint) {
        this.studentName = studentName;
        this.studentId = studentId;
        this.program = program;
        this.courseCode = courseCode;
        this.courseTitle = courseTitle;
        this.creditHours = creditHours;
        this.grade = grade;
        this.gradePoint = gradePoint;
    }

    public String getStudentName()   { return studentName; }
    public String getStudentId()     { return studentId; }
    public String getProgram()       { return program; }
    public String getCourseCode()    { return courseCode; }
    public String getCourseTitle()   { return courseTitle; }
    public double getCreditHours()   { return creditHours; }
    public String getGrade()         { return grade; }
    public double getGradePoint()    { return gradePoint; }
}
