package crs.assignment;

public class User extends Person {

    private String password;
    private String role;
    private String status;

    public User(String username, String email, String password, String role, String status) {
        super(username, email);
        this.password = password;
        this.role = role;
        this.status = status;
    }

    @Override
    public String getRoleDescription() {
        return "System user with role: " + role;
    }

    public String getUsername() { return name; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public String getStatus() { return status; }

    public void setUsername(String username) { this.name = username; }
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }
    public void setRole(String role) { this.role = role; }
    public void setStatus(String status) { this.status = status; }
}
