/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package crs.assignment;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ahmed
 */
public class EligibilityForm extends javax.swing.JPanel {
    
    private CRS_Frame parent;
    private List<AcademicRecord> allRecords;

    
    public EligibilityForm(CRS_Frame parent) {
        this.parent = parent;
        initComponents();
        DefaultTableModel model = (DefaultTableModel) eligibilityTable.getModel();
        model.setRowCount(0);
        eligibilityTable.setForeground(java.awt.Color.BLACK);
        eligibilityTable.getTableHeader().setForeground(java.awt.Color.BLACK);
        setupTable();
        loadData();
        populateStudentCombo();
        loadAllEnrolmentsIntoTable();
        resetForm();
    }

    public void resetForm() {
        if (studentIdCbEC.getItemCount() > 0) {
            studentIdCbEC.setSelectedIndex(0);
        }
        nameLblEC.setText("-");
        cgpaLblEC.setText("-");
        failedCourseLblEC.setText("-");
        lastFailedCourseIDs = "";
        DefaultTableModel model = (DefaultTableModel) eligibilityTable.getModel();
        model.setRowCount(0);
        loadAllEnrolmentsIntoTable();
    }

    public void refreshEligibilityData() {
        loadData(); 
        populateStudentCombo(); 
        loadAllEnrolmentsIntoTable();  
    }

    private void setupTable() {
        DefaultTableModel model = new DefaultTableModel(
        new String[]{ "StudentID" , "Student Name" , "EnrolmentLevel", "Date", "Status"},0)   
        {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
            }
        };
      eligibilityTable.setModel(model);
    }
    
    private void loadData() {
        allRecords = AcademicFileHandler.loadAllRecords();
    }
    
    private void populateStudentCombo() {
        Set<String> ids = new LinkedHashSet<>();
        for (AcademicRecord r : allRecords) {
            ids.add(r.getStudentId());
        }
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        model.addElement("Select Student");
        for (String id : ids) {
            model.addElement(id);
        }
        studentIdCbEC.setModel(model);
    }

    private String lastFailedCourseIDs = "";
    private void searchStudent() {
        String selectedId = (String) studentIdCbEC.getSelectedItem();
        if (selectedId == null || selectedId.equals("Select Student")) {
            JOptionPane.showMessageDialog(this, "Please select a student.");
            return;
        }
        List<String> failedCourseIDs = new ArrayList<>();
        double totalCredits = 0;
        double totalGradePoints = 0;
        int failCount = 0;
        String studentName = "";
        for (AcademicRecord r : allRecords) {
            if (r.getStudentId().equals(selectedId)) {
                studentName = r.getStudentName();
                totalCredits += r.getCreditHours();
                totalGradePoints += r.getCreditHours() * r.getGradePoint();
                String grade = r.getGrade().trim().toUpperCase();
                List<String> failingGrades = Arrays.asList("F", "D", "D+");
                if (failingGrades.contains(grade)) {
                    failCount++;
                    failedCourseIDs.add(r.getCourseCode());
                }
            }
        }
        double cgpa = totalCredits == 0 ? 0 : totalGradePoints / totalCredits;
        cgpaLblEC.setText(String.format("%.2f", cgpa));
        nameLblEC.setText(studentName);
        failedCourseLblEC.setText(String.valueOf(failCount)); 
        lastFailedCourseIDs = String.join(",", failedCourseIDs);
    }

    
    private boolean recordExists(String filePath, String studentId) {
        try {
            List<String> lines = java.nio.file.Files.readAllLines(java.nio.file.Paths.get(filePath));
            for (String line : lines) {
                if (line.startsWith(studentId + "\t")) {
                    return true;  
                }
            }
        } catch (Exception e) {
        }
        return false; 
    }
    
    private void saveNotEligibleStudent(String studentId, String studentName, double cgpa, int fails, String lastFailedCourseIDs) {
        String file = "txtFiles/StudentsForCR.txt";
            if (recordExists(file, studentId)) {
            JOptionPane.showMessageDialog(this, "Student already exists in StudentsForCR.txt");
            return;
        }
        String record = studentId + "\t" + studentName + "\t" + cgpa + "\t" + fails + "\t" + lastFailedCourseIDs + "\n";
        try {
            java.nio.file.Files.write(
                    java.nio.file.Paths.get(file),
                    record.getBytes(),
                    java.nio.file.StandardOpenOption.CREATE,
                    java.nio.file.StandardOpenOption.APPEND
            );
            JOptionPane.showMessageDialog(this, "Student added to StudentsForCR.txt");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saving to StudentsForCR.txt");
        }
    }

    private void checkEligibility() {
        if (cgpaLblEC.getText().equals("-")) {
            JOptionPane.showMessageDialog(this, "Please search a student first.");
            return;
        }
        double cgpa = Double.parseDouble(cgpaLblEC.getText());
        int fails = Integer.parseInt(failedCourseLblEC.getText());
        String studentId = (String) studentIdCbEC.getSelectedItem();
        String studentName = "";
        for (AcademicRecord r : allRecords) {
            if (r.getStudentId().equals(studentId)) {
                studentName = r.getStudentName();
                break;
            }
        }
        if (cgpa >= 2.0 && fails <= 3) {
            JOptionPane.showMessageDialog(this, "Student is ELIGIBLE for enrolment.");
            return;
        }
        JOptionPane.showMessageDialog(this, "Student is NOT eligible. Added to counselling list.");
        saveNotEligibleStudent(studentId, studentName, cgpa, fails, lastFailedCourseIDs);
    }

    private void loadAllEnrolmentsIntoTable() {
        DefaultTableModel model = (DefaultTableModel) eligibilityTable.getModel();
        model.setRowCount(0);
        try {
            List<String> lines = java.nio.file.Files.readAllLines(
                java.nio.file.Paths.get("txtFiles/Enrolments.txt")
            );
            for (String line : lines) {
                String[] parts = line.split("\t");
                if (parts.length >= 5) {
                    model.addRow(new Object[]{
                        parts[0],
                        parts[1],
                        parts[2],
                        parts[3],
                        parts[4]
                    });
                }
            }
        } catch (Exception e) {
            System.out.println("No enrolments found yet.");
        }
    }

    private void enrolStudent() {
        if (cgpaLblEC.getText().equals("-")) {
             JOptionPane.showMessageDialog(this, "Please search the student first.");
             return;
        }
        double cgpa = Double.parseDouble(cgpaLblEC.getText());
        int fails = Integer.parseInt(failedCourseLblEC.getText());
        if (cgpa < 2.0 || fails > 3) {
            JOptionPane.showMessageDialog(this, "Cannot enrol. Student is NOT eligible.");
            return;
        }
        String studentId = (String) studentIdCbEC.getSelectedItem();
        String studentName = "";
        for (AcademicRecord r : allRecords) {
            if (r.getStudentId().equals(studentId)) {
                studentName = r.getStudentName();
                break;
            }
        }
        String level = "Level 2";
        String date = java.time.LocalDate.now().toString();
        String status = "Successful";
        String file = "txtFiles/Enrolments.txt";
        if (recordExists(file, studentId)) {
            JOptionPane.showMessageDialog(this, "Student already exists in Enrolments.txt");
                return;
        }
            String record = studentId + "\t" + studentName + "\t" + level + "\t" + date + "\t" + status + "\n";
        try {
            java.nio.file.Files.write(
                java.nio.file.Paths.get("txtFiles/Enrolments.txt"),
                record.getBytes(),
                java.nio.file.StandardOpenOption.CREATE,
                java.nio.file.StandardOpenOption.APPEND
            );
            JOptionPane.showMessageDialog(this,
                "Enrolment recorded:\n" +
                "Student: " + studentId + "\n" +
                "Level: " + level + "\n" +
                "Date: " + date);           
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saving enrolment.");
            e.printStackTrace();
        }
        loadAllEnrolmentsIntoTable();
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scrollCourses = new javax.swing.JScrollPane();
        tblCourses = new javax.swing.JTable();
        BackBtnEC = new javax.swing.JButton();
        lblTitle = new javax.swing.JLabel();
        lblCgpaTitle = new javax.swing.JLabel();
        cgpaLblEC = new javax.swing.JLabel();
        failedCourseLblEC = new javax.swing.JLabel();
        lblFailsTitle = new javax.swing.JLabel();
        lblStudentId = new javax.swing.JLabel();
        checkBtnEC = new javax.swing.JButton();
        enrolBtnEC = new javax.swing.JButton();
        clearBtnEC = new javax.swing.JButton();
        scrollCourses1 = new javax.swing.JScrollPane();
        eligibilityTable = new javax.swing.JTable();
        studentIdCbEC = new javax.swing.JComboBox<>();
        searchBtnEC = new javax.swing.JButton();
        lblNameTitle = new javax.swing.JLabel();
        nameLblEC = new javax.swing.JLabel();

        tblCourses.setAutoCreateRowSorter(true);
        tblCourses.setForeground(new java.awt.Color(255, 255, 255));
        tblCourses.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Course Code", "Course Name", "Credit", "Grade"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        scrollCourses.setViewportView(tblCourses);

        setBackground(new java.awt.Color(240, 248, 255));

        BackBtnEC.setText("Back");
        BackBtnEC.setName("BackBtnEC"); // NOI18N
        BackBtnEC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnECActionPerformed(evt);
            }
        });

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTitle.setText("Eligibility Check & Enrolment");
        lblTitle.setName("lblTitle"); // NOI18N

        lblCgpaTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCgpaTitle.setText("CGPA:");
        lblCgpaTitle.setName("lblCgpaTitle"); // NOI18N

        cgpaLblEC.setText("-");
        cgpaLblEC.setName("cgpaLblEC"); // NOI18N

        failedCourseLblEC.setText("-");
        failedCourseLblEC.setName("failedCourseLblEC"); // NOI18N

        lblFailsTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblFailsTitle.setText("Failed Courses:");
        lblFailsTitle.setName("lblFailsTitle"); // NOI18N

        lblStudentId.setBackground(new java.awt.Color(0, 0, 0));
        lblStudentId.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblStudentId.setText("Student ID:");
        lblStudentId.setToolTipText("");
        lblStudentId.setName("lblStudentId"); // NOI18N

        checkBtnEC.setText("Check Eligibility");
        checkBtnEC.setName("checkBtnEC"); // NOI18N
        checkBtnEC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkBtnECActionPerformed(evt);
            }
        });

        enrolBtnEC.setText("Enrol");
        enrolBtnEC.setName("enrolBtnEC"); // NOI18N
        enrolBtnEC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enrolBtnECActionPerformed(evt);
            }
        });

        clearBtnEC.setText("Clear");
        clearBtnEC.setName("clearBtnEC"); // NOI18N
        clearBtnEC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtnECActionPerformed(evt);
            }
        });

        eligibilityTable.setAutoCreateRowSorter(true);
        eligibilityTable.setForeground(new java.awt.Color(255, 255, 255));
        eligibilityTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "StudentID", "Student Name", "EnrolmentLevel ", " Date    ", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrollCourses1.setViewportView(eligibilityTable);

        studentIdCbEC.setName("studentIdCbEC"); // NOI18N

        searchBtnEC.setText("Search");
        searchBtnEC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnECActionPerformed(evt);
            }
        });

        lblNameTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNameTitle.setText("Name");
        lblNameTitle.setName("lblCgpaTitle"); // NOI18N

        nameLblEC.setText("-");
        nameLblEC.setName("cqpaLblEC"); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(BackBtnEC, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(146, 146, 146)
                        .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(43, 43, 43)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblCgpaTitle)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cgpaLblEC))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblStudentId, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(studentIdCbEC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblFailsTitle)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(failedCourseLblEC, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblNameTitle)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(nameLblEC))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(checkBtnEC, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(clearBtnEC, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(searchBtnEC, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                                    .addComponent(enrolBtnEC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(scrollCourses1, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitle)
                    .addComponent(BackBtnEC, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblStudentId)
                            .addComponent(studentIdCbEC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNameTitle)
                            .addComponent(nameLblEC))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCgpaTitle)
                            .addComponent(cgpaLblEC))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblFailsTitle)
                            .addComponent(failedCourseLblEC))
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(checkBtnEC, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(clearBtnEC, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(searchBtnEC, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(enrolBtnEC, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
                        .addComponent(scrollCourses1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)))
                .addGap(49, 49, 49))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void checkBtnECActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkBtnECActionPerformed
        checkEligibility();
    }//GEN-LAST:event_checkBtnECActionPerformed

    private void enrolBtnECActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enrolBtnECActionPerformed
        enrolStudent();
    }//GEN-LAST:event_enrolBtnECActionPerformed


    private void BackBtnECActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnECActionPerformed
        if (parent == null) {
        return;
        }
        User u = parent.getCurrentUser();
        if (u == null) {
            parent.switchTo("login");
            return;
        }
        String role = u.getRole();
        if (role.equalsIgnoreCase("Course Administrator")) {
            parent.switchTo("course_admin_dash");
        } else if (role.equalsIgnoreCase("Academic Officer")) {
            parent.switchTo("academic_officer_dash");
        } else {
            parent.switchTo("login");
        }
    }//GEN-LAST:event_BackBtnECActionPerformed

    private void searchBtnECActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnECActionPerformed
        searchStudent();
    }//GEN-LAST:event_searchBtnECActionPerformed

    private void clearBtnECActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtnECActionPerformed
        resetForm();
    }//GEN-LAST:event_clearBtnECActionPerformed
            
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackBtnEC;
    private javax.swing.JLabel cgpaLblEC;
    private javax.swing.JButton checkBtnEC;
    private javax.swing.JButton clearBtnEC;
    private javax.swing.JTable eligibilityTable;
    private javax.swing.JButton enrolBtnEC;
    private javax.swing.JLabel failedCourseLblEC;
    private javax.swing.JLabel lblCgpaTitle;
    private javax.swing.JLabel lblFailsTitle;
    private javax.swing.JLabel lblNameTitle;
    private javax.swing.JLabel lblStudentId;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel nameLblEC;
    private javax.swing.JScrollPane scrollCourses;
    private javax.swing.JScrollPane scrollCourses1;
    private javax.swing.JButton searchBtnEC;
    private javax.swing.JComboBox<String> studentIdCbEC;
    private javax.swing.JTable tblCourses;
    // End of variables declaration//GEN-END:variables
}

