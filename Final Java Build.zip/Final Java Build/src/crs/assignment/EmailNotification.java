package crs.assignment;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import javax.mail.internet.MimeBodyPart;
import javax.mail.Multipart;
import javax.mail.internet.MimeMultipart;


public class EmailNotification {

    private static final String senderEmail = "noreply.crs.system@gmail.com";
    private static final String senderPassword = "sqfgugfcxhuvvkhq";

    public static void sendEmail(String to, String subject, String body) {

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(to)
            );
            message.setSubject(subject);
            message.setText(body);

            Transport.send(message);

            logEmail(to, subject, body, "SENT");

            System.out.println("Email sent successfully to: " + to);

        } catch (Exception e) {
            e.printStackTrace();

            logEmail(to, subject, body, "FAILED");

            System.out.println("Failed to send email to: " + to);
        }
    }

    public static void sendEmailWithAttachment(String to, String subject, String body, String filePath) {

        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");

            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(senderEmail, senderPassword);
                }
            });

            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);

            MimeBodyPart textPart = new MimeBodyPart();
            textPart.setText(body);

            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.attachFile(filePath);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(textPart);
            multipart.addBodyPart(attachmentPart);

            message.setContent(multipart);

            Transport.send(message);

            logEmail(to, subject, body + "\n[ATTACHMENT SENT: " + filePath + "]", "SENT");

        } catch (Exception e) {
            e.printStackTrace();
            logEmail(to, subject, body, "FAILED");
        }
    }
    
    private static void logEmail(String to, String subject, String body, String status) {

        String logEntry =
                "========================================\n" +
                "To: " + to + "\n" +
                "Subject: " + subject + "\n" +
                "Status: " + status + "\n" +
                "Timestamp: " + java.time.LocalDateTime.now() + "\n" +
                "----------------------------------------\n" +
                body + "\n" +
                "========================================\n\n";

        try {
            java.nio.file.Files.write(
                    java.nio.file.Paths.get("txtFiles/EmailLog.txt"),
                    logEntry.getBytes(),
                    java.nio.file.StandardOpenOption.CREATE,
                    java.nio.file.StandardOpenOption.APPEND
            );

        } catch (Exception e) {
            System.out.println("Failed to log email.");
        }
    }
}
