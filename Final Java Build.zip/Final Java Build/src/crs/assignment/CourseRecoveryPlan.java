package crs.assignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class CourseRecoveryPlan extends javax.swing.JPanel {

    private CRS_Frame parent;

    private static final String MILESTONES_FILE = "txtFiles/Milestones.txt";
    private static final String STUDENTS_FILE = "txtFiles/StudentsForCR.txt";

    private final List<String[]> allMilestones = new ArrayList<>();
    private final List<Integer> visibleMilestoneIndices = new ArrayList<>();

    private DefaultTableModel milestonesModel;
    private DefaultTableModel failedComponentsModel;

    public CourseRecoveryPlan(CRS_Frame parent) {
        this.parent = parent;
        initComponents();
        configureTables();
        loadMilestonesFile();
        populateStudentComboFromStudentsFile();
        wireListeners();
    }

    public void resetForm() {
        populateStudentComboFromStudentsFile();
        nameTxtCR.setText("");
        cgpaTxtCR.setText("");
        selectedStudentEmail = "";
        recommendationBtn.setText("");
        milestonesModel.setRowCount(0);
        failedComponentsModel.setRowCount(0);
        if (studentIdCb.getItemCount() > 0) {
            studentIdCb.setSelectedIndex(0);
        }
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        nameTxtCR = new javax.swing.JTextField();
        cgpaTxtCR = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        milestoneBtn = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        failedComponentsTable = new javax.swing.JTable();
        addRecommendationBtn = new javax.swing.JButton();
        removeRecommendationBtn = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        recommendationBtn = new javax.swing.JTextArea();
        saveBtnCR = new javax.swing.JButton();
        addMilestoneBtn = new javax.swing.JButton();
        toogleCompletedBtn = new javax.swing.JButton();
        mailBtnCR = new javax.swing.JButton();
        backBtnCR = new javax.swing.JButton();
        studentIdCb = new javax.swing.JComboBox<>();
        examResultBtn = new javax.swing.JButton();

        setBackground(new java.awt.Color(240, 248, 255));

        jLabel1.setText("Student Info");

        jLabel2.setText("Student ID");

        jLabel3.setText("Name");

        jLabel4.setText("CGPA");

        nameTxtCR.setEnabled(false);

        cgpaTxtCR.setEnabled(false);

        jLabel5.setText("Recommendations");

        jLabel6.setText("Milestones");

        milestoneBtn.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Week", "Range", "Task", "Deadline"
            }
        ));
        jScrollPane1.setViewportView(milestoneBtn);

        jLabel7.setText("Failed Components");

        failedComponentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Component", "Description"
            }
        ));
        jScrollPane2.setViewportView(failedComponentsTable);

        addRecommendationBtn.setText("Add Recommendation");
        addRecommendationBtn.setName("addRecomBtn"); // NOI18N

        removeRecommendationBtn.setText("Remove Recommendation");
        removeRecommendationBtn.setName("remRecomBtn"); // NOI18N
        removeRecommendationBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeRecommendationBtnActionPerformed(evt);
            }
        });

        recommendationBtn.setColumns(20);
        recommendationBtn.setRows(5);
        jScrollPane3.setViewportView(recommendationBtn);

        saveBtnCR.setText("Save");
        saveBtnCR.setName("saveBtn"); // NOI18N

        addMilestoneBtn.setText("Add Milestone");
        addMilestoneBtn.setName("addMileBtn"); // NOI18N

        toogleCompletedBtn.setText("Toggle Completed");
        toogleCompletedBtn.setName("toggleBtn"); // NOI18N

        mailBtnCR.setText("Mail");
        mailBtnCR.setName("mailBtn"); // NOI18N
        mailBtnCR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mailBtnCRActionPerformed(evt);
            }
        });

        backBtnCR.setText("Back");
        backBtnCR.setName("backBtn"); // NOI18N
        backBtnCR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnCRActionPerformed(evt);
            }
        });

        studentIdCb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        examResultBtn.setText("Record Exam Result");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel4)
                                                .addComponent(jLabel3))
                                            .addGap(24, 24, 24))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jLabel1)
                                            .addGap(37, 37, 37)))
                                    .addComponent(jLabel2)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(backBtnCR)
                                        .addGap(37, 37, 37)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(146, 146, 146)
                                        .addComponent(jLabel5))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(studentIdCb, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(cgpaTxtCR, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addGap(12, 12, 12)
                                                .addComponent(nameTxtCR, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(91, 91, 91)
                                        .addComponent(mailBtnCR))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(43, 43, 43)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(addRecommendationBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(removeRecommendationBtn)))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(273, 273, 273)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(236, 236, 236))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(toogleCompletedBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(addMilestoneBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(119, 119, 119))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(saveBtnCR)
                        .addGap(144, 144, 144))))
            .addGroup(layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addComponent(examResultBtn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jScrollPane3)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(addMilestoneBtn)
                            .addComponent(addRecommendationBtn))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(toogleCompletedBtn)
                            .addComponent(removeRecommendationBtn))
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(mailBtnCR)
                            .addComponent(saveBtnCR))
                        .addGap(72, 72, 72))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(backBtnCR)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(studentIdCb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(nameTxtCR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cgpaTxtCR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel7)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(examResultBtn)
                        .addGap(14, 14, 14))))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void removeRecommendationBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeRecommendationBtnActionPerformed
        onRemoveRecommendation();
    }//GEN-LAST:event_removeRecommendationBtnActionPerformed
    
    private void mailBtnCRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mailBtnCRActionPerformed
        if (selectedStudentEmail == null || selectedStudentEmail.isEmpty()) {
        JOptionPane.showMessageDialog(this, "No email found for this student.");
        return;
        }
        String id = (String) studentIdCb.getSelectedItem();
        String name = nameTxtCR.getText().trim();
        String cgpa = cgpaTxtCR.getText().trim();
        File pdf = generateCRPPdf(id, name, cgpa);
        if (pdf == null) {
            JOptionPane.showMessageDialog(this, "Could not generate PDF.");
            return;
        }
        String subject = "Course Recovery Plan Update for Student " + id;
        String body = 
                "Dear " + name + ",\n\n" +
                "Your updated Course Recovery Plan is attached as a PDF.\n\n" +
                "Regards,\nCRS System";
        try {
            EmailNotification.sendEmailWithAttachment(
                    selectedStudentEmail,
                    subject,
                    body,
                    pdf.getAbsolutePath()
            );
            JOptionPane.showMessageDialog(this, "Email with PDF sent to: " + selectedStudentEmail);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to send email.");
            ex.printStackTrace();
        }
    }//GEN-LAST:event_mailBtnCRActionPerformed

    private void backBtnCRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnCRActionPerformed
        if (parent == null) {
            return;
        }
        User u = parent.getCurrentUser();
        if (u == null) {
            parent.switchTo("login");
            return;
        }
        String role = u.getRole();
        if (role.equalsIgnoreCase("Course Administrator")) {
            parent.switchTo("course_admin_dash");
        } else if (role.equalsIgnoreCase("Academic Officer")) {
            parent.switchTo("academic_officer_dash");
        } else {
            parent.switchTo("login");
        }
    }//GEN-LAST:event_backBtnCRActionPerformed
    
    private void configureTables() {
        milestonesModel = new DefaultTableModel(
            new Object[]{"CourseID", "Milestone", "Deadline", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        milestoneBtn.setModel(milestonesModel);
        milestoneBtn.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        failedComponentsModel = new DefaultTableModel(
            new Object[]{"CourseID", "Status", "Attempt"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        failedComponentsTable.setModel(failedComponentsModel);
    }
    
    private void wireListeners() {
        studentIdCb.addActionListener(e -> onStudentChanged());
        examResultBtn.addActionListener(e -> onRecordExamResult());
        milestoneBtn.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                onMilestoneRowSelected();
            }
        });
        addRecommendationBtn.addActionListener(e -> onAddRecommendation());
        addMilestoneBtn.addActionListener(e -> onAddMilestone());
        toogleCompletedBtn.addActionListener(e -> onToggleCompleted());
        saveBtnCR.addActionListener(e -> onSaveAll());
    }
    
    private void loadMilestonesFile() {
        allMilestones.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(MILESTONES_FILE))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; continue; }
                String[] p = line.split("\t");
                if (p.length < 6) continue;
                p[3] = p[3].replace("\\n", "\n");
                allMilestones.add(p);
            }
        } catch (Exception ex) {
            System.out.println("Missing milestones file.");
        }
    }
    
    private void populateStudentComboFromStudentsFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(STUDENTS_FILE))) {
            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            model.addElement("Select Student ID");
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { 
                    first = false; 
                    continue;
                }
                String[] p = line.split("\t");
                if (p.length >= 1) {
                    model.addElement(p[0].trim());
                }
            }
            studentIdCb.setModel(model);
            studentIdCb.setSelectedIndex(0);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Could not load StudentsForCR.txt");
        }
    }

    private void onRecordExamResult() {
        int row = failedComponentsTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a course first.");
            return;
        }
        String courseId = failedComponentsModel.getValueAt(row, 0).toString();
        int attempt = Integer.parseInt(failedComponentsModel.getValueAt(row, 2).toString());
        String[] options = {"PASS", "FAIL"};
        int choice = JOptionPane.showOptionDialog(
                this,
                "Enter result for " + courseId + ":",
                "Exam Result",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );

        if (choice == 0) {
            handlePass(courseId, attempt, row);
        } else if (choice == 1) {
            handleFail(courseId, attempt, row);
        }
    }

    private void handlePass(String courseId, int attempt, int row) {
        String studentId = (String) studentIdCb.getSelectedItem();
        List<String> courses = new ArrayList<>();
        List<Integer> attempts = new ArrayList<>();
        for (int i = 0; i < failedComponentsModel.getRowCount(); i++) {
            if (i == row) continue;
            courses.add(failedComponentsModel.getValueAt(i, 0).toString());
            attempts.add(Integer.parseInt(failedComponentsModel.getValueAt(i, 2).toString()));
        }
        updateStudentsFile(studentId, courses, attempts);
        double newCgpa = recalculateCgpa(studentId, courseId);
        updateCgpaInCRFile(studentId, newCgpa);
        boolean perfUpdated = updateStudentsPerformanceFile(studentId, courseId);
        if (!perfUpdated) {
            JOptionPane.showMessageDialog(this, 
                "Warning: Some records could not be updated.\nPlease check the files.");
        }
        cgpaTxtCR.setText(String.format("%.2f", newCgpa));
        failedComponentsModel.removeRow(row);
        JOptionPane.showMessageDialog(this,
            "Student PASSED " + courseId +
            "\nNew CGPA: " + String.format("%.2f", newCgpa));
    }

    private void handleFail(String courseId, int attempt, int row) {
        String studentId = (String) studentIdCb.getSelectedItem();
        int newAttempt = attempt + 1;
        if (newAttempt >= 3) {
            failedComponentsModel.setValueAt("Full Module Resit Required", row, 1);
            failedComponentsModel.setValueAt(3, row, 2);
            List<String> courses = new ArrayList<>();
            List<Integer> attempts = new ArrayList<>();
            for (int i = 0; i < failedComponentsModel.getRowCount(); i++) {
                courses.add(failedComponentsModel.getValueAt(i, 0).toString());
                attempts.add(Integer.parseInt(failedComponentsModel.getValueAt(i, 2).toString()));
            }
            updateStudentsFile(studentId, courses, attempts);
            JOptionPane.showMessageDialog(this,
                    "Student FAILED " + courseId +
                    "\nThis is the THIRD attempt.\n\n➡ The student must RESIT the ENTIRE MODULE now.",
                    "Full Module Resit Required",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        failedComponentsModel.setValueAt("Failed", row, 1);
        failedComponentsModel.setValueAt(newAttempt, row, 2);
        List<String> courses = new ArrayList<>();
        List<Integer> attempts = new ArrayList<>();
        for (int i = 0; i < failedComponentsModel.getRowCount(); i++) {
            courses.add(failedComponentsModel.getValueAt(i, 0).toString());
            attempts.add(Integer.parseInt(failedComponentsModel.getValueAt(i, 2).toString()));
        }
        updateStudentsFile(studentId, courses, attempts);
        JOptionPane.showMessageDialog(this,
                "Student FAILED " + courseId +
                "\nAttempts updated to " + newAttempt + ".");
    }

    private boolean updateStudentsPerformanceFile(String studentId, String courseId) {
        try {
            String filePath = "txtFiles/StudentsPerformance.txt";
            List<String> lines = java.nio.file.Files.readAllLines(java.nio.file.Paths.get(filePath));
            List<String> updated = new ArrayList<>();
            boolean first = true;
            boolean updatedSomething = false;
            for (String line : lines) {
                if (first) {
                    updated.add(line);
                    first = false;
                    continue;
                }
                if (line.trim().isEmpty()) {
                    updated.add(line);
                    continue;
                }
                String[] p = line.split("\t");
                String lineStudentId = p[1].trim();
                String lineCourseCode = p[3].trim();
                if (lineStudentId.equals(studentId) && lineCourseCode.equals(courseId)) {
                    p[6] = "C";
                    p[7] = "2.0";
                    updated.add(String.join("\t", p));
                    updatedSomething = true;
                } else {
                    updated.add(line);
                }
            }
            java.nio.file.Files.write(
                java.nio.file.Paths.get(filePath),
                updated,
                java.nio.file.StandardOpenOption.TRUNCATE_EXISTING
            );
            return updatedSomething;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void updateStudentsFile(String studentId, List<String> updatedCourses, List<Integer> updatedAttempts) {

        try {
            List<String> lines = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader(STUDENTS_FILE))) {

                String line;
                boolean first = true;
                while ((line = br.readLine()) != null) {
                    if (first) {
                        lines.add(line);
                        first = false;
                        continue;
                    }
                    String[] p = line.split("\t");

                    if (!p[0].equals(studentId)) {
                        lines.add(line);
                        continue;
                    }
                    String coursesStr = String.join(",", updatedCourses);
                    List<String> attemptStrList = new ArrayList<>();
                    for (int a : updatedAttempts) attemptStrList.add(String.valueOf(a));
                    String attemptsStr = String.join(",", attemptStrList);
                    String updatedLine =
                            p[0] + "\t" +
                            p[1] + "\t" +
                            p[2] + "\t" +
                            updatedCourses.size() + "\t" +
                            coursesStr + "\t" +
                            attemptsStr;
                    lines.add(updatedLine);
                }
            }
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(STUDENTS_FILE))) {
                for (String l : lines) bw.write(l + "\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating StudentsForCR.txt");
        }
    }

    
    private void onStudentChanged() {
        String id = (String) studentIdCb.getSelectedItem();
        if (id == null) return;
        loadStudentInfo(id);
        loadFailedComponents(id);
        loadMilestonesForStudent(id);
    }
    
    private String selectedStudentEmail = "";

    private List<Integer> currentAttempts = new ArrayList<>();
    private List<String> currentCourses = new ArrayList<>();

    private void loadStudentInfo(String id) {
        nameTxtCR.setText("");
        cgpaTxtCR.setText("");
        String fullName = "";
        String cgpa = "";
        String email = "";
        currentCourses.clear();
        currentAttempts.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(STUDENTS_FILE))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; continue; }
                String[] p = line.split("\t");
                if (p[0].equals(id)) {
                    fullName = p[1];
                    cgpa = p[2];
                    if (p.length >= 5) {
                        String[] courses = p[4].split(",");
                        for (String c : courses) currentCourses.add(c.trim());
                    }
                    if (p.length >= 6) {
                        String[] attempts = p[5].split(",");
                        for (String a : attempts) currentAttempts.add(Integer.parseInt(a.trim()));
                    }
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading StudentsForCR.txt");
        }

        try (BufferedReader br = new BufferedReader(new FileReader("txtFiles/Students.txt"))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; continue; }
                String[] p = line.split("\t");
                if (p[0].equals(id)) {
                    email = p[5];
                    break;
                }
            }
        } catch (Exception e) {}
        nameTxtCR.setText(fullName);
        cgpaTxtCR.setText(cgpa);
        selectedStudentEmail = email;
    }

    private void loadFailedComponents(String id) {
        failedComponentsModel.setRowCount(0);
        for (int i = 0; i < currentCourses.size(); i++) {
            String course = currentCourses.get(i);
            int attempt = (i < currentAttempts.size()) ? currentAttempts.get(i) : 1;
            failedComponentsModel.addRow(new Object[]{course,"Failed",attempt});
        }
    }

    private double recalculateCgpa(String studentId, String passedCourseId) {

        List<AcademicRecord> all = AcademicFileHandler.loadAllRecords();
        double totalCredits = 0;
        double totalGradePoints = 0;
        for (AcademicRecord r : all) {
            if (!r.getStudentId().equals(studentId)) 
                continue;
            double gradePoint = r.getGradePoint();
            double credit = r.getCreditHours();
            if (r.getCourseCode().equals(passedCourseId)) {
                gradePoint = 2.0;
            }
            totalCredits += credit;
            totalGradePoints += credit * gradePoint;
        }
        if (totalCredits == 0) return 0;
        return totalGradePoints / totalCredits;
    }

    private void updateCgpaInCRFile(String studentId, double newCgpa) {

        try {
            List<String> lines = java.nio.file.Files.readAllLines(java.nio.file.Paths.get(STUDENTS_FILE));
            List<String> updated = new ArrayList<>();
            boolean first = true;
            for (String line : lines) {
                if (first) {
                    updated.add(line);
                    first = false;
                    continue;
                }
                String[] p = line.split("\t");        
                if (p[0].equals(studentId)) {
                    String failedCourses = (p.length >= 5 ? p[4] : "");
                    String attempts = (p.length >= 6 ? p[5] : "");
                    String newLine = studentId + "\t" + p[1] + "\t" +
                                     String.format("%.2f", newCgpa) + "\t" +
                                     p[3] + "\t" + failedCourses + "\t" + attempts;
                    updated.add(newLine);
                } else {
                    updated.add(line);
                }
            }
            java.nio.file.Files.write(
                java.nio.file.Paths.get(STUDENTS_FILE),
                updated,
                java.nio.file.StandardOpenOption.TRUNCATE_EXISTING
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating CGPA in CR file.");
        }
    }

    private void loadMilestonesForStudent(String id) {
        milestonesModel.setRowCount(0);
        visibleMilestoneIndices.clear();
        recommendationBtn.setText("");
        for (int i = 0; i < allMilestones.size(); i++) {
            String[] m = allMilestones.get(i);
            if (m[0].equals(id)) {
                milestonesModel.addRow(new Object[]{m[1], m[2], m[4], m[5]});
                visibleMilestoneIndices.add(i);
            }
        }
    }
    
    private void onMilestoneRowSelected() {
        int row = milestoneBtn.getSelectedRow();
        if (row < 0) return;
        int idx = visibleMilestoneIndices.get(row);
        recommendationBtn.setText(allMilestones.get(idx)[3]);
    }
    
    private void onAddRecommendation() {
        int row = milestoneBtn.getSelectedRow();
        if (row < 0) return;
        String newRec = JOptionPane.showInputDialog("Enter recommendation:");
        if (newRec == null || newRec.trim().isEmpty()) return;
        String prev = recommendationBtn.getText();
        if (!prev.isEmpty()) prev += "\n";
        recommendationBtn.setText(prev + newRec);
        updateCurrentMilestoneRecommendations();
    }
    
    private void updateCurrentMilestoneRecommendations() {
        int row = milestoneBtn.getSelectedRow();
        if (row < 0) return;
        int idx = visibleMilestoneIndices.get(row);
        allMilestones.get(idx)[3] = recommendationBtn.getText();
    }
    
    private void onRemoveRecommendation() {
        int row = milestoneBtn.getSelectedRow();
        if (row < 0) return;
        recommendationBtn.setText("");
        updateCurrentMilestoneRecommendations();
    }
    
    private boolean isValidDate(String dateStr) {
        try {
            java.time.LocalDate.parse(dateStr);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void onAddMilestone() {
        String studentId = (String) studentIdCb.getSelectedItem();
        if (studentId == null) return;
        List<String> failedCourses = new ArrayList<>();
        for (int i = 0; i < failedComponentsModel.getRowCount(); i++) {
            String cid = failedComponentsModel.getValueAt(i, 0).toString().trim();
            if (!cid.isEmpty()) {
                failedCourses.add(cid);
            }
        }
        if (failedCourses.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No failed components available to assign milestones.");
            return;
        }
        String[] options = failedCourses.toArray(new String[0]);
        String courseID = (String) JOptionPane.showInputDialog(
                this,
                "Select Course ID:",
                "Add Milestone",
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );
        if (courseID == null) return;
        for (int i = 0; i < failedComponentsModel.getRowCount(); i++) {
            String cid = failedComponentsModel.getValueAt(i, 0).toString();
            if (cid.equals(courseID)) {
                int att = Integer.parseInt(failedComponentsModel.getValueAt(i, 2).toString());
                if (att >= 3) {
                    JOptionPane.showMessageDialog(this,
                            "You cannot add a milestone for " + courseID +
                            "\nThe student has reached 3 attempts and must resit the entire module.",
                            "Full Module Resit Required",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
        }
        String milestone = JOptionPane.showInputDialog(this, "Enter Milestone:");
        if (milestone == null || milestone.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Milestone cannot be empty.");
            return;
        }
        milestone = milestone.trim();
        String deadline = JOptionPane.showInputDialog(this, "Enter Deadline (YYYY-MM-DD):");
        if (deadline == null) return;
        deadline = deadline.trim();
        while (!isValidDate(deadline)) {
            deadline = JOptionPane.showInputDialog(
                    this,
                    "Invalid date format!\nPlease enter a valid date in format YYYY-MM-DD:",
                    "Invalid Date",
                    JOptionPane.ERROR_MESSAGE
            );
            if (deadline == null) return;
            deadline = deadline.trim();
        }
        String[] newRow = { studentId, courseID, milestone, "", deadline, "Not Started" };
        allMilestones.add(newRow);
        loadMilestonesForStudent(studentId);
    }

    private void onToggleCompleted() {
        int row = milestoneBtn.getSelectedRow();
        if (row < 0) return;
        int idx = visibleMilestoneIndices.get(row);
        String status = allMilestones.get(idx)[5];
        if (status.equals("Not Started")) status = "In Progress";
        else if (status.equals("In Progress")) status = "Completed";
        else status = "Not Started";
        allMilestones.get(idx)[5] = status;
        milestonesModel.setValueAt(status, row, 3);
    }
    
    private void onSaveAll() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(MILESTONES_FILE))) {
            bw.write("StudentID\tCourseID\tMilestone\tRecommendations\tDeadline\tStatus\n");
            for (String[] m : allMilestones) {
                bw.write(m[0] + "\t" + m[1] + "\t" + m[2] + "\t" +
                         m[3].replace("\n", "\\n") + "\t" + m[4] + "\t" + m[5] + "\n");
            }
            JOptionPane.showMessageDialog(this, "Saved!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saving file.");
        }
    }

    private File generateCRPPdf(String studentId, String studentName, String cgpa) {
        try {
            String fileName = "CRP_" + studentId + ".pdf";
            File file = new File(fileName);
            com.lowagie.text.Document doc = new com.lowagie.text.Document();
            com.lowagie.text.pdf.PdfWriter.getInstance(doc, new java.io.FileOutputStream(file));
            doc.open();
            com.lowagie.text.Font titleFont = com.lowagie.text.FontFactory.getFont(com.lowagie.text.FontFactory.HELVETICA_BOLD, 18);
            com.lowagie.text.Font normalFont = com.lowagie.text.FontFactory.getFont(com.lowagie.text.FontFactory.HELVETICA, 12);
            doc.add(new com.lowagie.text.Paragraph("Course Recovery Plan for " + studentName + " (" + studentId + ")\n\n", titleFont));
            doc.add(new com.lowagie.text.Paragraph("CGPA: " + cgpa + "\n\n", normalFont));
            for (int i = 0; i < visibleMilestoneIndices.size(); i++) {
                int idx = visibleMilestoneIndices.get(i);
                String[] m = allMilestones.get(idx);
                doc.add(new com.lowagie.text.Paragraph(
                    (i+1) + ") Course: " + m[1] + "\n" +
                    "   Milestone: " + m[2] + "\n" +
                    "   Deadline: " + m[4] + "\n" +
                    "   Status: " + m[5] + "\n", 
                    normalFont
                ));
                String recs = m[3].trim();
                if (recs.isEmpty()) {
                    doc.add(new com.lowagie.text.Paragraph("   Recommendations: (none)\n\n", normalFont));
                } else {
                    doc.add(new com.lowagie.text.Paragraph("   Recommendations:\n", normalFont));
                    for (String r : recs.split("\n")) {
                        doc.add(new com.lowagie.text.Paragraph("      - " + r, normalFont));
                    }
                    doc.add(new com.lowagie.text.Paragraph("\n"));
                }
            }
            doc.close();
            return file;
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to generate PDF.");
            return null;
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addMilestoneBtn;
    private javax.swing.JButton addRecommendationBtn;
    private javax.swing.JButton backBtnCR;
    private javax.swing.JTextField cgpaTxtCR;
    private javax.swing.JButton examResultBtn;
    private javax.swing.JTable failedComponentsTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton mailBtnCR;
    private javax.swing.JTable milestoneBtn;
    private javax.swing.JTextField nameTxtCR;
    private javax.swing.JTextArea recommendationBtn;
    private javax.swing.JButton removeRecommendationBtn;
    private javax.swing.JButton saveBtnCR;
    private javax.swing.JComboBox<String> studentIdCb;
    private javax.swing.JButton toogleCompletedBtn;
    // End of variables declaration//GEN-END:variables
}
