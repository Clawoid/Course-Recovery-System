package crs.assignment;

public class OfficerUser extends User {

    public OfficerUser(String username, String email, String password, String status) {
        super(username, email, password, "Academic Officer", status);
    }

    @Override
    public String getRoleDescription() {
        return "Academic Officer — handles enrolments, eligibility checks, and student progress.";
    }
}
