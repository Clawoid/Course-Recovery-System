package crs.assignment;

public class AdminUser extends User {

    public AdminUser(String username, String email, String password, String status) {
        super(username, email, password, "Course Administrator", status);
    }

    @Override
    public String getRoleDescription() {
        return "Administrator — manages users, academic records, and system controls.";
    }
}
