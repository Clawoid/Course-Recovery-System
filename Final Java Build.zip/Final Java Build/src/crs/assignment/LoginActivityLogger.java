package crs.assignment;

import java.io.DataOutputStream;
import java.io.FileOutputStream;

public class LoginActivityLogger {

    private static final String FILE_PATH = "txtFiles/LoginActivity.dat";

    public static void log(String username, String action) {
        try (DataOutputStream out = new DataOutputStream(
            new FileOutputStream(FILE_PATH, true))) {

            long timestamp = System.currentTimeMillis();

            out.writeUTF(username);
            out.writeUTF(action);
            out.writeLong(timestamp);

            System.out.println("Logged activity: " + username + " - " + action);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to log login activity.");
        }
    }
}
