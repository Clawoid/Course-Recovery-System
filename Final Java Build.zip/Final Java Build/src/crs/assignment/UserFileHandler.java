package crs.assignment;

import java.io.*;
import java.util.*;

public class UserFileHandler {

    private static final String FILE_PATH = "txtFiles/Users.txt";

    public static List<User> loadUsers() {
        List<User> users = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            boolean skipHeader = true;
            while ((line = br.readLine()) != null) {
                if (skipHeader) {
                    skipHeader = false;
                    continue;
                }
                String[] parts = line.split("\\t+");
                if (parts.length < 5) continue;

                String username = parts[0].trim();
                String email = parts[1].trim();
                String password = parts[2].trim();
                String role = parts[3].trim();
                String status = parts[4].trim();

                users.add(new User(username, email, password, role, status));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return users;
    }

    public static boolean addUser(User user) {

        List<User> existingUsers = loadUsers();

        for (User u : existingUsers) {
            if (u.getUsername().equalsIgnoreCase(user.getUsername()) ||
                u.getEmail().equalsIgnoreCase(user.getEmail())) {
                return false; 
            }
        }
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH, true))) {

            bw.write(
                    user.getUsername() + "\t" +
                    user.getEmail() + "\t" +
                    user.getPassword() + "\t" +
                    user.getRole() + "\t" +
                    user.getStatus()
            );
            bw.newLine();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static List<User> getAllUsers() {
        return loadUsers();
    }

    public static User findUserByUsername(String username) {
        for (User u : loadUsers()) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                return u;
            }
        }
        return null;
    }
    
    public static boolean updateUser(
        String oldUsername,
        String newUsername,
        String newEmail,
        String newPassword,
        String newRole
    ) {
        List<User> users = loadUsers();
        boolean updated = false;

        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(oldUsername)) {

                u.setUsername(newUsername);
                u.setEmail(newEmail);

                if (!newPassword.isEmpty()) {
                    u.setPassword(newPassword);
                }

                u.setRole(newRole);

                updated = true;
                break;
            }
        }

        if (!updated) return false;

        return saveAllUsers(users);
    }

    public static boolean deactivateUser(String username) {
        List<User> users = loadUsers();
        boolean updated = false;

        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                u.setStatus("Inactive");
                updated = true;
                break;
            }
        }

        if (!updated) return false;

        return saveAllUsers(users);
    }
    
    public static boolean activateUser(String username) {
        List<User> users = loadUsers();
        boolean updated = false;

        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                u.setStatus("Active");
                updated = true;
                break;
            }
        }

        if (!updated) return false;

        return saveAllUsers(users);
    }

    
    private static boolean saveAllUsers(List<User> users) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {

            bw.write("Username\tEmail\tPassword\tRole\tStatus");
            bw.newLine();

            for (User u : users) {
                bw.write(
                    u.getUsername() + "\t" +
                    u.getEmail() + "\t" +
                    u.getPassword() + "\t" +
                    u.getRole() + "\t" +
                    u.getStatus()
                );
                bw.newLine();
            }

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}


