package crs.assignment;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

public class LoginActivityReader {

    private static final String FILE_PATH = "txtFiles/LoginActivity.dat";

    public static List<String> readLogs() {
        List<String> logs = new ArrayList<>();

        try (DataInputStream in = new DataInputStream(new FileInputStream(FILE_PATH))) {

            while (in.available() > 0) {

                String username = in.readUTF();
                String action = in.readUTF();
                long timestamp = in.readLong();

                String entry = username + " | " + action + " | " + 
                               new java.util.Date(timestamp).toString();

                logs.add(entry);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return logs;
    }
}
