package crs.assignment;

import java.util.List;
import crs.assignment.AdminUser;
import crs.assignment.OfficerUser;


public class AuthenticationService {

    public AuthenticationService() {}

    public User login(String username, String password) {
        List<User> userList = UserFileHandler.getAllUsers();

        for (User u : userList) {

            if (u.getUsername().equalsIgnoreCase(username.trim())
                    && u.getPassword().trim().equals(password.trim())
                    && u.getStatus().equalsIgnoreCase("Active")) {

                if (u.getRole().equalsIgnoreCase("Course Administrator")) {
                    return new AdminUser(
                        u.getUsername(),
                        u.getEmail(),
                        u.getPassword(),
                        u.getStatus()
                    );
                }
                else if (u.getRole().equalsIgnoreCase("Academic Officer")) {
                    return new OfficerUser(
                        u.getUsername(),
                        u.getEmail(),
                        u.getPassword(),
                        u.getStatus()
                    );
                }
                return u;
            }
        }
        return null;
    }
}
