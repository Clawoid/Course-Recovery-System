package crs.assignment;

import java.io.*;
import java.util.*;

public class AcademicFileHandler {

    private static final String FILE_PATH = "txtFiles/StudentsPerformance.txt";

    public static List<AcademicRecord> loadAllRecords() {
        List<AcademicRecord> list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            boolean skipHeader = true;

            while ((line = br.readLine()) != null) {

                if (skipHeader) {
                    skipHeader = false;
                    continue;
                }

                if (line.trim().isEmpty()) continue;

                String[] parts = line.split("\\t+");
                if (parts.length < 8) continue;

                String studentName = parts[0].trim();
                String studentId   = parts[1].trim();
                String program     = parts[2].trim();
                String courseCode  = parts[3].trim();
                String courseTitle = parts[4].trim();

                double creditHours;
                double gradePoint;

                try {
                    creditHours = Double.parseDouble(parts[5].trim());
                } catch (NumberFormatException e) {
                    creditHours = 0;
                }

                String grade = parts[6].trim();

                try {
                    gradePoint = Double.parseDouble(parts[7].trim());
                } catch (NumberFormatException e) {
                    gradePoint = 0;
                }

                list.add(new AcademicRecord(
                        studentName, studentId, program,
                        courseCode, courseTitle,
                        creditHours, grade, gradePoint
                ));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return list;
    }
}
